"""Views, one for each Insta485 page."""
from insta485.views.index import *
from insta485.views.user import *
from insta485.views.post import *
from insta485.views.accounts import *
from insta485.views.likes import *
from insta485.views.comments import *
from insta485.views.follow import *
from insta485.views.explore import *
