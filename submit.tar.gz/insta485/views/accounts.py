"""Insta485 Account view."""
import pathlib
import os
import flask
import insta485
from insta485.views.db_portal import PostsPortal, \
    UsersPortal
from insta485.views.helper import password_hash, store_file, \
        get_target, check_filename


@insta485.app.route('/accounts/', methods=['POST'])
def handle_account_post():
    """Handle post methods for /accounts/ URL."""
    users_tb = UsersPortal()

    operation = flask.request.form.get("operation")
    if operation == "login":
        username = flask.request.form.get("username")
        password = flask.request.form.get("password")
        if not username or not password:
            flask.abort(400)

        if not users_tb.verify_password(username, password):
            return flask.abort(403)

        flask.session['username'] = flask.request.form['username']

    elif operation == "create":
        if "file" not in flask.request.files:
            flask.abort(400)
        fileobj = flask.request.files["file"]
        filename = fileobj.name
        check_filename(filename)
        fullname = flask.request.form.get("fullname")
        username = flask.request.form.get("username")
        email = flask.request.form.get("email")
        password = flask.request.form.get("password")
        if not fullname or not username or not email or not password:
            flask.abort(400)

        if users_tb.verify_user(username):
            flask.abort(409)

        uuid_basename = store_file(filename, fileobj)

        users_tb.create(uuid_basename, username, fullname,
                        email, password)

        flask.session['username'] = flask.request.form['username']

    elif operation == "delete":
        if "username" not in flask.session:
            return flask.abort(403)

        file_list = []
        logname = flask.session["username"]

        if not users_tb.verify_user(logname):
            return flask.redirect(flask.url_for("login"))

        # if not users_tb.verify_user(logname):
        #     flask.abort(403)

        posts_tb = PostsPortal()
        post_list = posts_tb.get_post_list(logname)
        for post in post_list:
            file_list.append(insta485.app.
                             config["UPLOAD_FOLDER"]/post["filename"])
        file_list.append(insta485.app.config["UPLOAD_FOLDER"]/users_tb.
                         get_user_img(logname))

        for file in file_list:
            if os.path.exists(file):
                os.remove(file)

        users_tb.delete(logname)
        flask.session.clear()

    elif operation == "edit_account":
        if "username" not in flask.session:
            return flask.abort(403)
        logname = flask.session["username"]

        if not users_tb.verify_user(logname):
            return flask.redirect(flask.url_for("login"))

        fullname = flask.request.form.get("fullname")
        email = flask.request.form.get("email")
        if not fullname or not email:
            flask.abort(400)

        # if not users_tb.verify_user(logname):
        #     flask.abort(403)

        uuid_basename = None
        if "file" in flask.request.files:
            fileobj = flask.request.files["file"]
            filename = fileobj.filename
            if filename:
                uuid_basename = store_file(filename, fileobj)
                # delete old img
                upload_folder = insta485.app.config["UPLOAD_FOLDER"]
                old_img = upload_folder/users_tb.get_user_img(logname)
                if os.path.exists(old_img):
                    os.remove(old_img)

        users_tb.update(logname, fullname, email, uuid_basename)

    elif operation == "update_password":
        if "username" not in flask.session:
            return flask.abort(403)

        logname = flask.session["username"]

        if not users_tb.verify_user(logname):
            return flask.redirect(flask.url_for("login"))

        password = flask.request.form.get("password")
        new_password1 = flask.request.form.get("new_password1")
        new_password2 = flask.request.form.get("new_password2")

        # if not users_tb.verify_user(logname):
        #     flask.abort(403)

        if not password or not new_password1 or not new_password2:
            return flask.abort(400)

        if not users_tb.verify_password(logname, password):
            return flask.abort(403)

        if new_password1 != new_password2:
            return flask.abort(401)

        new_password = password_hash(new_password1)

        users_tb.update_password(logname, new_password)

    return flask.redirect(get_target())


@insta485.app.route("/accounts/create/", methods=['GET'])
def get_account_create():
    """Create a new account."""
    if "username" in flask.session:
        return flask.redirect("/accounts/edit/")
    return flask.render_template("account_create.html")


@insta485.app.route('/accounts/logout/', methods=['POST'])
def logout():
    """Logout of Insta485."""
    if "username" not in flask.session:
        return flask.redirect(flask.url_for('login'))
    flask.session.clear()
    return flask.redirect(flask.url_for('login'))


@insta485.app.route('/accounts/login/', methods=['GET'])
def login():
    """Login to your account."""
    if "username" in flask.session:
        return flask.redirect(flask.url_for('show_index'))
    return flask.render_template("account_login.html")


@insta485.app.route('/accounts/delete/', methods=['GET'])
def delete():
    """Delete an account."""
    if "username" not in flask.session:
        return flask.redirect(flask.url_for('login'))
    logname = flask.session["username"]
    users_tb = UsersPortal()
    if not users_tb.verify_user(logname):
        return flask.redirect(flask.url_for("login"))

    context = {
        "logname": logname
    }
    return flask.render_template("account_delete.html", **context)


@insta485.app.route('/accounts/edit/', methods=['GET'])
def edit():
    """Edit an account."""
    if "username" not in flask.session:
        return flask.redirect(flask.url_for('login'))

    logname = flask.session["username"]

    users_tb = UsersPortal()
    if not users_tb.verify_user(logname):
        return flask.redirect(flask.url_for("login"))

    uploads_folder = pathlib.Path("/uploads/")

    context = {
        "logname": logname,
        "logname_img_url": uploads_folder/users_tb.get_user_img(logname),
        "fullname": users_tb.get_user_fullname(logname),
        "email": users_tb.get_user_email(logname),
    }

    return flask.render_template("account_edit.html", **context)


@insta485.app.route('/accounts/password/', methods=['GET'])
def password():
    """Create a new password."""
    if "username" not in flask.session:
        return flask.redirect(flask.url_for('login'))

    logname = flask.session["username"]
    users_tb = UsersPortal()
    if not users_tb.verify_user(logname):
        return flask.redirect(flask.url_for("login"))

    context = {
        "logname": logname,
    }

    return flask.render_template("account_password.html", **context)


@insta485.app.route("/accounts/auth/", methods=['GET'])
def auth():
    """Verify that the username cookie is being stored."""
    if "username" not in flask.session:
        flask.abort(403)
    return "", 200
