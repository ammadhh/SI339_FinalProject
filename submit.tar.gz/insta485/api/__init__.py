"""Insta485 REST API."""

from insta485.api.posts import get_post

import insta485.api.likes
import insta485.api.comments