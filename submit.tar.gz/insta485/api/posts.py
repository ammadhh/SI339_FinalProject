"""REST API for posts."""
import flask
import insta485
from insta485.views.db_portal import PostsPortal, UsersPortal, CommentsPortal, LikesPortal
from insta485.api.helper import auth_user
@insta485.app.route('/api/v1/posts/')
def get_posts():
    logname = auth_user()
    if logname == '':
        flask.abort(403)
    posts_tb, users_tb, likes_tb, comments_tb = PostsPortal(), UsersPortal(), LikesPortal(), CommentsPortal()
    if not users_tb.verify_user(logname):
        return flask.redirect(flask.url_for("login"))
    offset = 0
    postid_lte = flask.request.args.get('postid_lte',type=int)
    last_id = 2 ** 32
    if postid_lte:
        last_id = postid_lte
    size = flask.request.args.get('size',default=10,type=int)
    if(size < 0):
        error_response = flask.jsonify({
            "message": "Bad Request",
            "status_code": 400
        })
        response = flask.make_response(error_response, 400)
        return response
    page = flask.request.args.get('page',default=0,type=int)
    if page < 0:
        error_response = flask.jsonify({
            "message": "Bad Request",
            "status_code": 400
        })
        response = flask.make_response(error_response, 400)
        return response
    page = page * size
    url = flask.request.path
    nexturl = flask.request.path
    posts = posts_tb.get_next_posts(logname, size, page, last_id)
    query_params = flask.request.args.to_dict()
    if 'size' not in query_params:
        query_params["size"] = 10
    if 'page' in query_params:
        query_params["page"] = str(int(query_params["page"]) + 1)
    else:
        query_params["page"] = "1"
    lte = 0
    #TODO : Fix this and make sure if -1 page number it returns error 
    if(posts):
        lte = posts[0]["postid"]
    if 'postid_lte' not in query_params:
        query_params['postid_lte'] = lte
    ordered_params = ['size', 'page', 'postid_lte']
    query_string = flask.request.path + "?" + "&".join([f"{param}={query_params[param]}" for param in ordered_params if param in query_params])
    # query_string = "&".join([f"{key}={value}" for key, value in query_params.items()])
    print("Query",flask.request.query_string.decode('utf-8'))
    print(len(flask.request.query_string.decode('utf-8')))


    print("Testing Enviormental factors")
    if len(flask.request.query_string.decode('utf-8')) > 0:
        url = f"{flask.request.path}?{flask.request.query_string.decode('utf-8')}"
    else:
        url = flask.request.path
        # nexturl = f"{flask.request.path}?{flask.request.query_string.decode('utf-8')}"
    # else:
        # if not specified, we just set it to the last post, 
        # nexturl = f"{flask.request.path}?{flask.request.query_string.decode('utf-8')}&postid_lte={lte}"
    if(len(posts) < size):
        query_string = ''
    # TODO: UNKNOWN if line below needed does cause errors if is there erro ris that if list is empty it is ok but if uncommented below it just returns 404 when empty list 
    # if not posts:
    #     flask.abort(404)
    #Add API url
    for post in posts:
        post["url"] = f'{flask.request.path}{post["postid"]}/'
    # Dictionary for API Initalize
    outall = {}
    # Next needed items
    # TODO: Add next url for pagination example next?=2 -> next?=3 
    outall["next"] = query_string
    # Place Post Results in Dictionary
    outall["results"] = posts
    # URL from request path
    outall["url"] = url

    return flask.jsonify(**outall)
@insta485.app.route('/api/v1/posts/<int:postid_url_slug>/')
def get_post(postid_url_slug):
    """Return post on postid.
    """
    logname = auth_user()
    if logname == '':
        flask.abort(403)
    posts_tb = PostsPortal()
    users_tb = UsersPortal()
    likes_tb = LikesPortal()
    comments_tb = CommentsPortal()
    if not users_tb.verify_user(logname):
        return flask.redirect(flask.url_for("login"))
    
    post = posts_tb.get_post(postid_url_slug)

    if not post:
        error_response = flask.jsonify({
            "message": "Not Found",
            "status_code": 404
        })
        
        response = flask.make_response(error_response, 404)
        return response
    print(post)
    post_logname_like = likes_tb.logname_likes_post(logname, postid_url_slug)
    
    likes = {
        "lognameLikesThis": post_logname_like is not None,
        "numLikes": likes_tb.get_post_likes(postid_url_slug),
        "url": "/api/v1/likes/{}/".format(post_logname_like["likeid"]) if \
            post_logname_like is not None else None
    }
    
    comments = comments_tb.get_comments(postid_url_slug)
    for comment in comments:
        comment["ownerShowUrl"] = "/users/{}/".format(comment["owner"])
        comment["lognameOwnsThis"] = comment["owner"] == logname
        comment["url"] = "/api/v1/comments/{}/".format(comment["commentid"])
        del comment["created"]
    context = {
        "comments": comments,
        "comments_url": "/api/v1/comments/?postid={}".format(postid_url_slug),
        "created": post["created"],
        "imgUrl": post["img_url"],
        "owner": post["owner"],
        "likes" : likes,
        "ownerImgUrl": "/uploads/" + users_tb.get_user_img(post["owner"]),
        "ownerShowUrl": "/users/awdeorio/",
        "postid": postid_url_slug,
        "postShowUrl": "/posts/{}/".format(postid_url_slug),
        "url": flask.request.path,
    }
    return flask.jsonify(**context)
@insta485.app.route('/api/v1/', methods=["GET"])
def api_routes():
    dicts = {  "comments": "/api/v1/comments/",
  "likes": "/api/v1/likes/",
  "posts": "/api/v1/posts/",
  "url": "/api/v1/"
  }
    return dicts

