import flask
import insta485
from insta485.views.db_portal import PostsPortal, UsersPortal, CommentsPortal, LikesPortal
from insta485.api.helper import auth_user

@insta485.app.route('/api/v1/likes/', methods = ['POST',])
def like_post():
    """Likes a post and returns like object"""
    postid_url_slug = flask.request.args.get('postid')
    logname = auth_user()
    if logname == '':
        flask.abort(403)
    
    likes_tb = LikesPortal()
    posts_tb = PostsPortal()

    post = posts_tb.get_post(postid_url_slug)
    if not post: #If post is out of range, abort with 404 error
        flask.abort(404)
    likes_obj = likes_tb.like_post(postid_url_slug, logname)

    context = likes_obj[0]

    return flask.jsonify(**context), likes_obj[1]

@insta485.app.route('/api/v1/likes/<int:likeid_url_slug>/', methods = ['DELETE',])
def unlike_post(likeid_url_slug):
    """Unlikes a post and aborts if there's an error"""
    logname = auth_user()
    if logname == '':
        flask.abort(403)

    likes_tb = LikesPortal()
    
    http_code = likes_tb.unlike_post(likeid_url_slug, logname)

    if http_code != 204:
        flask.abort(http_code)
    else:
        return ('', http_code)