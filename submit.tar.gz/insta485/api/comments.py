import flask
import insta485
from insta485.views.db_portal import PostsPortal, UsersPortal, CommentsPortal, LikesPortal
from insta485.api.helper import auth_user

@insta485.app.route('/api/v1/comments/', methods = ['POST',])
def comment_post():
    """Comments on a post and returns json object"""
    postid_url_slug = flask.request.args.get('postid')
    logname = auth_user()
    if logname == '':
        flask.abort(403)
    
    comment_tb = CommentsPortal()
    text = False
    fullitems = {"owner": logname, "lognameOwnsThis": True, "ownerShowUrl": "/users/{}/".format(logname)}
    if flask.request.json and 'text' in flask.request.json:
        text = flask.request.json['text']
        # Now you can use the 'text' variable in your code
        fullitems["text"] = text
        comment_id = comment_tb.post_comment_api(text,postid_url_slug,logname)["last_insert_rowid()"]
        fullitems["commentid"] = comment_id
        fullitems["url"] = flask.request.path + "{}/".format(comment_id)
        return flask.jsonify(**fullitems), 201

    if not text: #If post is out of range, abort with 404 error
        flask.abort(404)
    

    return flask.jsonify(**fullitems)

@insta485.app.route('/api/v1/comments/<int:likeid_url_slug>/', methods = ['DELETE',])
def del_comms(likeid_url_slug):
    # Delete Comments method ret
    logname = auth_user()
    if logname == '':
        flask.abort(403)

    comments_tb = CommentsPortal()
    http_code = comments_tb.api_delete_comment(likeid_url_slug, logname)
    if http_code != 204:
        flask.abort(http_code)
    else:
        return ('', http_code)
    